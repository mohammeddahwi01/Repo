<?php


namespace Request\Module\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface RequestFormRepositoryInterface
{

    /**
     * Save RequestForm
     * @param \Request\Module\Api\Data\RequestFormInterface $requestForm
     * @return \Request\Module\Api\Data\RequestFormInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Request\Module\Api\Data\RequestFormInterface $requestForm
    );

    /**
     * Retrieve RequestForm
     * @param string $requestformId
     * @return \Request\Module\Api\Data\RequestFormInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getById($requestformId);

    /**
     * Retrieve RequestForm matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Request\Module\Api\Data\RequestFormSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    /**
     * Delete RequestForm
     * @param \Request\Module\Api\Data\RequestFormInterface $requestForm
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(
        \Request\Module\Api\Data\RequestFormInterface $requestForm
    );

    /**
     * Delete RequestForm by ID
     * @param string $requestformId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($requestformId);
}
