<?php


namespace Request\Module\Api\Data;

interface RequestFormInterface
{

    const TELEPHONE = 'telephone';
    const NAME = 'name';
    const COMMENT = 'comment';
    const REQUESTFORM_ID = 'requestform_id';
    const EMAIL = 'email';

    /**
     * Get requestform_id
     * @return string|null
     */
    public function getRequestformId();

    /**
     * Set requestform_id
     * @param string $requestformId
     * @return \Request\Module\Api\Data\RequestFormInterface
     */
    public function setRequestformId($requestformId);

    /**
     * Get name
     * @return string|null
     */
    public function getName();

    /**
     * Set name
     * @param string $name
     * @return \Request\Module\Api\Data\RequestFormInterface
     */
    public function setName($name);

    /**
     * Get email
     * @return string|null
     */
    public function getEmail();

    /**
     * Set email
     * @param string $email
     * @return \Request\Module\Api\Data\RequestFormInterface
     */
    public function setEmail($email);

    /**
     * Get telephone
     * @return string|null
     */
    public function getTelephone();

    /**
     * Set telephone
     * @param string $telephone
     * @return \Request\Module\Api\Data\RequestFormInterface
     */
    public function setTelephone($telephone);

    /**
     * Get comment
     * @return string|null
     */
    public function getComment();

    /**
     * Set comment
     * @param string $comment
     * @return \Request\Module\Api\Data\RequestFormInterface
     */
    public function setComment($comment);
}
