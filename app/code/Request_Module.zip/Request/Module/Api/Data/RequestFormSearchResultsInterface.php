<?php


namespace Request\Module\Api\Data;

interface RequestFormSearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get RequestForm list.
     * @return \Request\Module\Api\Data\RequestFormInterface[]
     */
    public function getItems();

    /**
     * Set name list.
     * @param \Request\Module\Api\Data\RequestFormInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}
