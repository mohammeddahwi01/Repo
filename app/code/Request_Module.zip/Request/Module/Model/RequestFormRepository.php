<?php


namespace Request\Module\Model;

use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Api\DataObjectHelper;
use Request\Module\Api\RequestFormRepositoryInterface;
use Magento\Framework\Reflection\DataObjectProcessor;
use Request\Module\Api\Data\RequestFormInterfaceFactory;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Api\SortOrder;
use Magento\Framework\Exception\NoSuchEntityException;
use Request\Module\Api\Data\RequestFormSearchResultsInterfaceFactory;
use Request\Module\Model\ResourceModel\RequestForm\CollectionFactory as RequestFormCollectionFactory;
use Request\Module\Model\ResourceModel\RequestForm as ResourceRequestForm;

class RequestFormRepository implements RequestFormRepositoryInterface
{

    protected $resource;

    protected $requestFormFactory;

    protected $requestFormCollectionFactory;

    protected $dataRequestFormFactory;

    private $storeManager;
    protected $dataObjectProcessor;

    protected $dataObjectHelper;

    protected $searchResultsFactory;


    /**
     * @param ResourceRequestForm $resource
     * @param RequestFormFactory $requestFormFactory
     * @param RequestFormInterfaceFactory $dataRequestFormFactory
     * @param RequestFormCollectionFactory $requestFormCollectionFactory
     * @param RequestFormSearchResultsInterfaceFactory $searchResultsFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param DataObjectProcessor $dataObjectProcessor
     * @param StoreManagerInterface $storeManager
     */
    public function __construct(
        ResourceRequestForm $resource,
        RequestFormFactory $requestFormFactory,
        RequestFormInterfaceFactory $dataRequestFormFactory,
        RequestFormCollectionFactory $requestFormCollectionFactory,
        RequestFormSearchResultsInterfaceFactory $searchResultsFactory,
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor,
        StoreManagerInterface $storeManager
    ) {
        $this->resource = $resource;
        $this->requestFormFactory = $requestFormFactory;
        $this->requestFormCollectionFactory = $requestFormCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataRequestFormFactory = $dataRequestFormFactory;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->storeManager = $storeManager;
    }

    /**
     * {@inheritdoc}
     */
    public function save(
        \Request\Module\Api\Data\RequestFormInterface $requestForm
    ) {
        /* if (empty($requestForm->getStoreId())) {
            $storeId = $this->storeManager->getStore()->getId();
            $requestForm->setStoreId($storeId);
        } */
        try {
            $this->resource->save($requestForm);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the requestForm: %1',
                $exception->getMessage()
            ));
        }
        return $requestForm;
    }

    /**
     * {@inheritdoc}
     */
    public function getById($requestFormId)
    {
        $requestForm = $this->requestFormFactory->create();
        $this->resource->load($requestForm, $requestFormId);
        if (!$requestForm->getId()) {
            throw new NoSuchEntityException(__('RequestForm with id "%1" does not exist.', $requestFormId));
        }
        return $requestForm;
    }

    /**
     * {@inheritdoc}
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        $collection = $this->requestFormCollectionFactory->create();
        foreach ($criteria->getFilterGroups() as $filterGroup) {
            $fields = [];
            $conditions = [];
            foreach ($filterGroup->getFilters() as $filter) {
                if ($filter->getField() === 'store_id') {
                    $collection->addStoreFilter($filter->getValue(), false);
                    continue;
                }
                $fields[] = $filter->getField();
                $condition = $filter->getConditionType() ?: 'eq';
                $conditions[] = [$condition => $filter->getValue()];
            }
            $collection->addFieldToFilter($fields, $conditions);
        }
        
        $sortOrders = $criteria->getSortOrders();
        if ($sortOrders) {
            /** @var SortOrder $sortOrder */
            foreach ($sortOrders as $sortOrder) {
                $collection->addOrder(
                    $sortOrder->getField(),
                    ($sortOrder->getDirection() == SortOrder::SORT_ASC) ? 'ASC' : 'DESC'
                );
            }
        }
        $collection->setCurPage($criteria->getCurrentPage());
        $collection->setPageSize($criteria->getPageSize());
        
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);
        $searchResults->setTotalCount($collection->getSize());
        $searchResults->setItems($collection->getItems());
        return $searchResults;
    }

    /**
     * {@inheritdoc}
     */
    public function delete(
        \Request\Module\Api\Data\RequestFormInterface $requestForm
    ) {
        try {
            $this->resource->delete($requestForm);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__(
                'Could not delete the RequestForm: %1',
                $exception->getMessage()
            ));
        }
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function deleteById($requestFormId)
    {
        return $this->delete($this->getById($requestFormId));
    }
}
