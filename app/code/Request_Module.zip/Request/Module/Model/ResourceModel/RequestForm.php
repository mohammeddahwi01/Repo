<?php


namespace Request\Module\Model\ResourceModel;

class RequestForm extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('request_module_requestform', 'requestform_id');
    }
}
