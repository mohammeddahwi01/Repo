<?php


namespace Request\Module\Model;

use Request\Module\Api\Data\RequestFormInterface;

class RequestForm extends \Magento\Framework\Model\AbstractModel implements RequestFormInterface
{

    protected $_eventPrefix = 'request_module_requestform';

    /**
     * @return void
     */
    protected function _construct()
    {
        $this->_init(\Request\Module\Model\ResourceModel\RequestForm::class);
    }

    /**
     * Get requestform_id
     * @return string
     */
    public function getRequestformId()
    {
        return $this->getData(self::REQUESTFORM_ID);
    }

    /**
     * Set requestform_id
     * @param string $requestformId
     * @return \Request\Module\Api\Data\RequestFormInterface
     */
    public function setRequestformId($requestformId)
    {
        return $this->setData(self::REQUESTFORM_ID, $requestformId);
    }

    /**
     * Get name
     * @return string
     */
    public function getName()
    {
        return $this->getData(self::NAME);
    }

    /**
     * Set name
     * @param string $name
     * @return \Request\Module\Api\Data\RequestFormInterface
     */
    public function setName($name)
    {
        return $this->setData(self::NAME, $name);
    }

    /**
     * Get email
     * @return string
     */
    public function getEmail()
    {
        return $this->getData(self::EMAIL);
    }

    /**
     * Set email
     * @param string $email
     * @return \Request\Module\Api\Data\RequestFormInterface
     */
    public function setEmail($email)
    {
        return $this->setData(self::EMAIL, $email);
    }

    /**
     * Get telephone
     * @return string
     */
    public function getTelephone()
    {
        return $this->getData(self::TELEPHONE);
    }

    /**
     * Set telephone
     * @param string $telephone
     * @return \Request\Module\Api\Data\RequestFormInterface
     */
    public function setTelephone($telephone)
    {
        return $this->setData(self::TELEPHONE, $telephone);
    }

    /**
     * Get comment
     * @return string
     */
    public function getComment()
    {
        return $this->getData(self::COMMENT);
    }

    /**
     * Set comment
     * @param string $comment
     * @return \Request\Module\Api\Data\RequestFormInterface
     */
    public function setComment($comment)
    {
        return $this->setData(self::COMMENT, $comment);
    }
}
