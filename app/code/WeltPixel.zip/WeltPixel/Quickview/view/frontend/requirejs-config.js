var config = {
    map: {
        '*': {
            magnificPopup: 'WeltPixel_Quickview/js/jquery.magnific-popup.min',            
            weltpixel_quickview: 'WeltPixel_Quickview/js/weltpixel_quickview'
        }
    },
    shim: {
        magnificPopup: {
            deps: ['jquery']
        }
    }
};