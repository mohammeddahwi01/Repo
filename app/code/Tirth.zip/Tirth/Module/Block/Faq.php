<?php
namespace Tirth\Module\Block;
 
use Tirth\Module\Model\Post;
use Magento\Framework\Data\Collection;
use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;

       class Faq extends Template
       {
              // protected $_modelextratagsFactory;
               protected $_postFactory;

            public function __construct(Context $context, 
                   /* ExtratagsFactory $MainmodelextratagsFactory,*/
                    \Tirth\Module\Model\PostFactory $postFactory, 
                    array $data = [])
                {
                 /*   $this->_modelextratagsFactory = $MainmodelextratagsFactory;*/
                    $this->_postFactory = $postFactory;
                    parent::__construct($context, $data);
                }
                
           public function faqdata()
           {
              $MyCollection = $this->_postFactory->create()
                            ->getCollection();
               return $MyCollection;
           }
        }