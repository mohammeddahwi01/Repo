<?php

namespace Tirth\Module\Controller\Index;
 
use Magento\Framework\App\Action\Context;

class Index extends \Magento\Framework\App\Action\Action
{
    protected $_pageFactory;
    protected $_formFactory;
    protected $_postFactory;

    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $pageFactory,
        \Tirth\Module\Model\PostFactory $postFactory,
        \Tirth\Module\Model\FormFactory $formFactory
        )
    {
        $this->_pageFactory = $pageFactory;
        $this->_postFactory = $postFactory;
        $this->_formFactory = $formFactory;
        return parent::__construct($context);
    }

    public function execute()
    {   
        


        // $form = $this->_formFactory->create();
        // $collection=$form->getCollection();
        // foreach($collection as $item){
        //      echo "<pre>";
        //      print_r($item->getData());
        //      exit();
        // }
        // $post = $this->_postFactory->create();
        // $collection = $post->getCollection();
        // foreach($collection as $item){
        //     echo "<pre>";
        //     print_r($item->getData());
        //     echo "</pre>";
        //}
    
        return $this->_pageFactory->create();
    }
}